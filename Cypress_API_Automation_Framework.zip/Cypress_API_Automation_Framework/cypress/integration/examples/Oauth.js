/// <reference types = "Cypress" />

const data = require('../../fixtures/example')



describe('Test the authorization', () => {

    let client_id = ""
    let access_token = ""

    it('Create a secret key', () => {

        cy.request({

            method: 'POST',
            url: data.url + '/api/v1/Client',    
            body:{
                "name" : data.username,
                "secret": data.password
            }
        }).then(res=>{
            client_id = res.body.id

            console.log(client_id)
            cy.request({
                method: 'POST',
                url: data.url + '/connect/token', 
                form:true,
                body: {
                    "client_id": client_id,
                    "client_secret": data.password,
                    "grant_type": "password",
                    "username": data.username,
                    "password": data.password,
                    "scope": data.scope
                }
            }).then((res) => {
                console.log(JSON.stringify(res))
                expect(res.status).to.eq(200)  
                access_token = res.body.access_token
                })

        })
    })

})