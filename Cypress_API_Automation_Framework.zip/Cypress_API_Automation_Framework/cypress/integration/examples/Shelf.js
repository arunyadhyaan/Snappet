/// <reference types = "Cypress" />

const data = require('../../fixtures/example')



describe('Test shelf APIs', () => {


    let randomText = ""
    let Generated_shelf_id = ""
    let Generated_shelf_name = ""
    let New_shelf_id = ""
    let id_to_delete = ""
    let access_token = ""
    let client_id = ""
    let shelfid_to_delete = ""
    let shelfid_to_update = ""
    let updated_shelfid = ""

    var pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    for (var i = 0; i < 10; i++)
        randomText += pattern.charAt(Math.floor(Math.random() * pattern.length));
    Generated_shelf_id = 'ShelfId ' + randomText
    Generated_shelf_name = 'ShelfName ' + randomText

    before('generate token', () => {
        cy.request({

            method: 'POST',
            url: data.url + 'api/v1/Client',
            body: {
                "name": data.username,
                "secret": data.password
            }
        }).then((res) => {
            client_id = res.body.id

            //console.log(client_id)
            cy.request({
                method: 'POST',
                url: data.url + 'connect/token',
                form: true,
                body: {
                    "client_id": client_id,
                    "client_secret": data.password,
                    "grant_type": "password",
                    "username": data.username,
                    "password": data.password,
                    "scope": data.scope
                }
            }).then((res) => {
                //expect(res.status).to.eq(200)
                access_token = res.body.access_token
                //console.log("access token is " + access_token)


                cy.request({
                    method: 'GET',
                    url: data.url + 'api/v1/Shelf',
                    
                    headers: {
                        
                        'Authorization': "Bearer " + access_token,
                        'Accept': "application/json"
                    }
                    
                })
            })
        })


    })




    it('Create a shelf', () => {

        cy.request({
            method: 'POST',
            url: data.url + 'api/v1/Shelf',
            headers: {
                'authorization': "Bearer " + access_token
            },
            body: {
                "id": Generated_shelf_id,
                "name": Generated_shelf_name
            }
        }).then((res) => {
            expect(res.status).to.eq(201)
            expect(res.body).to.have.property('name', Generated_shelf_name)
        })
    })


    it('Update a shelf', () => {

        cy.request({
            method: 'GET',
            url: data.url + 'api/v1/Shelf',
            headers: {
                'authorization': "Bearer " + access_token
            }
        }).then((res) => {
            console.log(JSON.stringify(res.body))
            shelfid_to_update = res.body[0].id;
            console.log("shelfid_to_update is " + shelfid_to_update)
            console.log(shelfid_to_update)
            expect(res.status).to.eq(200)
        }).then((res) => {          

            cy.request({
                method: 'PUT',
                url: data.url + 'api/v1/Shelf',
                headers: {
                    'authorization': "Bearer " + access_token
                },
                body: {
                    "id": shelfid_to_update,
                    "name": Generated_shelf_name + "Snappet"
                }
            })
        }).then((res) => {
            expect(res.status).to.eq(200)
            cy.request({
                method: 'GET',
                url: data.url + 'api/v1/Shelf/' + shelfid_to_update,
                headers: {
                    'authorization': "Bearer " + access_token
                }
            }).then((res) => {
                expect(res.body).to.have.property('name', Generated_shelf_name + "Snappet")
            })
        })
    })

    it('Delete a shelve', () => {

        cy.request({
            method: 'DELETE',
            url: data.url + 'api/v1/Shelf/' + shelfid_to_delete,
            headers: {
                'authorization': "Bearer " + access_token
            }
        }).then((res) => {
            expect(res.status).to.eq(200)        
            cy.request({
                method: 'GET',
                url: data.url + 'api/v1/Shelf/' + shelfid_to_delete,
                headers: {
                    'authorization': "Bearer " + access_token
                }
            }).then((res) => {
                expect(res.status).to.eq(404)
            })
        })

    })

})