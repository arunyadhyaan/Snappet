/// <reference types="cypress" />
// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

module.exports = (on, config) => {

    on('task', {
      sqlServerDB1: sql => {
        return execSQL(sql, config.env.db1)
      },
    }),
  
    on('task', {
      sqlServerDB2: sql => {
        return execSQL(sql, config.env.db2)
      },
    })
  
  return config
  
  }
  
  const tedious = require('tedious')
  function execSQL(sql, config) {
  const connection = new tedious.Connection(config);
  return new Promise((res, rej) => {
    connection.on('connect', err => {
      if (err) {
        rej(err);
      }
  
      const request = new tedious.Request(sql, function (err, rowCount, rows) {
        return err ? rej(err) : res(rows);
      });
  
      connection.execSql(request);
    });
  })
  }
  
  //Read excel
  
   const xlsx = require("xlsx");
   
   module.exports = (on, config) => {
     // `on` is used to hook into various events Cypress emits
     // `config` is the resolved Cypress config
     on("task", {        
       generateJSONFromExcel: generateJSONFromExcel     
     });
     console.log("config");
     return config;
   };
  
   
   // Excel To JSON
   function generateJSONFromExcel(agrs) {
     const wb = xlsx.readFile(agrs.excelFilePath);
     const ws = wb.Sheets[agrs.sheetName];
     return xlsx.utils.sheet_to_json(ws, { raw: false });
   }
  
  const cucumber = require('cypress-cucumber-preprocessor').default;
  
  module.exports = (on, config) => {
    on('file:preprocessor', cucumber())
  };
       
  
  