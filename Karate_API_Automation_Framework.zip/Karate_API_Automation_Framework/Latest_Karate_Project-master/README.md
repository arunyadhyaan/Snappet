# Latest_Karate_Project
Its latest and simple karate project easy to understand
Based on this you can create your own Karate framework

