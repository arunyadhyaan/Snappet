function fn() {
  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'prod';
  }
  var config = {
    apiurl: "https://boyns97jh5.execute-api.eu-west-1.amazonaws.com/Prod/"
  }
  if (env == 'prod') {
    config.user_id = 'alice'
    config.password = 'alice'
    config.scope='librarian'
    config.granttype='password'
    
  } else if (env == 'e2e') {
    // customize
  }
  return config;
}