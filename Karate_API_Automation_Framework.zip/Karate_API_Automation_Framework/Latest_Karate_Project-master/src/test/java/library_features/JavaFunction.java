package library_features;

public class JavaFunction {


}
