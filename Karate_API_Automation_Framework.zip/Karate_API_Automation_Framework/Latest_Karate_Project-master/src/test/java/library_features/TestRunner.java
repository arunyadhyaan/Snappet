
package library_features;

import com.intuit.karate.junit5.Karate;

class TestRunner {
    
    @Karate.Test
    Karate testUsers() {
        return Karate.run("classpath:library_features/Book.feature").relativeTo(getClass());
    }    

}
