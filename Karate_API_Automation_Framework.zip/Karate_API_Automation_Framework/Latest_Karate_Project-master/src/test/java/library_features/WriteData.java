package library_features;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class WriteData {
	public static void getShelfWriteData(String arg) throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("getShelfResponse.json", "UTF-8");
		writer.println(arg);
		writer.close();
	}
	public static void getBookWriteData(String arg) throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("getBookResponse.json", "UTF-8");
		writer.println(arg);
		writer.close();
	}
	

}
